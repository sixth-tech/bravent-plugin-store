# Bravent ??/CapCut+

## Latest update - v2.2.2

- Unified the Property Inspector bottom with the refined Bravent footer system.
- Reduced footer visual weight so support text feels quieter and more premium.
- No shortcut behavior, action count, or deck visuals changed.

A lightweight Rhythm Deck / Bravent Hub shortcut pack for Jianying Pro / 剪映专业版 desktop.

## Why We Made This

The old pack had too many buttons and several shortcuts did not exist in the current local Jianying Pro shortcut profiles. This version now ships the complete keyboard-safe action set: all stable keyboard commands plus profile-labeled variants where Jianying profiles use different keys.

## Who It Is For

- Tier: Basic
- Best for: editors who want a complete keyboard shortcut surface for timeline, edit, trim, group, preview, marker, subtitle, audio, view, and profile-specific controls.
- Requires: Jianying Pro / 剪映专业版 desktop installed.
- Does not require: login, helper app, background server, or external account.

## What It Does

- 102 keyboard actions generated from the local Jianying shortcut profiles.
- Refined Property Inspector based on the Smart Snippets visual system.
- Shows selected action, shortcut, category, keep reason, and verification notes.

## How To Use

1. Install the plugin in Bravent Hub.
2. Drag the actions you need to Rhythm Deck.
3. Open Jianying Pro / 剪映专业版 desktop.
4. Click the editor or timeline area.
5. Press the Rhythm Deck key.

## v2.2.1 update

- Replaced Plugin Title and Action Icon assets with white-line transparent icons.
- Kept all existing Deck Visual assets unchanged.
- No shortcut behavior changed.

## Version

- Current: v2.2.2
- Release date: 2026-06-01
- Update channel: stable

## What Stayed

The plugin includes 66 commands that are the same across all five local shortcut profiles and 18 profile-dependent commands as separate Default/FCP variants.

## Complete Shortcut Audit

The local Jianying shortcut config exposes 66 keyboard command IDs that are the same across all profiles, 18 keyboard command IDs that change by profile, 7 mouse/wheel/hold actions that need runtime handling, and 1 command with no shortcut. The keyboard-safe set is now included in v2.2.0.

## What Was Removed

Not included as buttons: mouse/wheel/hold actions and commands with no shortcut in the local Jianying config.

Profile-specific commands are labeled as Default or FCP so the user can choose the correct keymap.

## Support

Feedback / Report a problem  
Email: sixth@bravent.co  
Bravent® All rights reserved 2025.  
Bravent Hub 剪映/CapCut+© v2.2.2
