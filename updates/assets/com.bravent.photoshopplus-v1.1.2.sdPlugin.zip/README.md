# Bravent Photoshop+

## Latest update - v1.1.2

- Unified the Property Inspector bottom with the refined Bravent footer system.
- Updated public-facing copy from Photoshop Hotkey to Bravent Photoshop+.
- No shortcut mappings, action count, or icon assets changed.

Manifest-only Rhythm Deck / StreamDock hotkey plugin using the working `com.hotspot.streamdock.hotkey.*` UUID pattern.

Actions: 168
Default/reference actions: 168
Custom mapping slots: 0

Icon layout:

- Top 60%: semantic transparent PNG line icon from `images/line-icons`.
- Middle 30%: action name.
- Bottom 10%: shortcut key.

Notes:

- Existing installed Photoshop plugin was not modified.
- Adobe Photoshop shortcuts vary by version, workspace, keyboard layout, and custom shortcut set.
- Some Adobe shortcuts are mouse/hold/drag based and cannot be represented by this manifest-only one-keystroke method.
- Custom slots can be mapped in Photoshop via Keyboard Shortcuts.
- Includes Bravent-style Property Inspector cards with `Use / Function`, `How / When`, and `Setting required` guidance.
- Added useful layer shortcut: `Create/Release Clipping Mask (Ctrl+Alt+G)`.

Install:

1. Close Bravent Hub / Rhythm Deck.
2. Copy this whole folder into `C:\Users\solar\AppData\Roaming\HotSpot\StreamDock\plugins`.
3. Restart Bravent Hub / Rhythm Deck.
4. Open Photoshop and test Save, Brush Tool, Move Tool, Free Transform, or Zoom In.

Shortcut list is in `shortcuts.csv`.


Smart Object/Link actions setup (required):

- Open Photoshop keyboard shortcuts: Alt+Shift+Ctrl+K.
- In Application Menus set:
  - Layer > Smart Objects > Convert to Smart Object -> Ctrl+Alt+Shift+C
  - Layer > Smart Objects > New Smart Object Via Copy -> Ctrl+Alt+Shift+J
  - Layer > Link Layers -> Ctrl+Alt+Shift+D
- Click Accept, then Save the shortcut set.

## Support

Feedback / Report a problem  
Email: sixth@bravent.co  
Bravent® All rights reserved 2025.  
Bravent Hub Photoshop+? v1.1.2
